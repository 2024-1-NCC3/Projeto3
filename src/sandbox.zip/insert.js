var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var sqlite3 = require("sqlite3").verbose();

var PORT = process.env.PORT || 3002; // Usar uma porta diferente se necessário
var DBPATH = "dadosnibd.db";

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var db = new sqlite3.Database(DBPATH, (err) => {
  if (err) {
    console.error("Erro ao abrir o banco de dados:", err.message);
  } else {
    console.log("Conectado ao banco de dados SQLite.");
  }
});

// criação da tabela progresso_usuario
app.get("/criar-tabela-progresso", (req, res) => {
  const createTableProgresso = `
  CREATE TABLE IF NOT EXISTS progresso_usuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_primeiro_conteudo INTEGER,
    id_usuario INTEGER,
    total_correta_primeiro_conteudo INTEGER,
    total_correta_segundo_conteudo INTEGER,
    total_correta_terceiro_conteudo INTEGER,
    total_correta_quarto_conteudo INTEGER,
    FOREIGN KEY (id_primeiro_conteudo) REFERENCES primeiro_conteudo(id),
    FOREIGN KEY (id_usuario) REFERENCES usuario(id)
    )
  `;

  db.run(createTableProgresso, (err) => {
    if (err) {
      res.status(500).send("Erro ao criar tabela: " + err.message);
    } else {
      res.send("Tabela 'usuario' criada com sucesso.");
    }
  });
});
// criação da tabela usuário
app.get("/criar-tabela-user", (req, res) => {
  const createTableUser = `
  CREATE TABLE IF NOT EXISTS usuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dsc_nome_user TEXT NOT NULL,
    senha TEXT NOT NULL,
    dsc_email_user TEXT NOT NULL
    )
  `;

  db.run(createTableUser, (err) => {
    if (err) {
      res.status(500).send("Erro ao criar tabela: " + err.message);
    } else {
      res.send("Tabela 'usuario' criada com sucesso.");
    }
  });
});

// Adicionando rota para criar a nova tabela 'primeiro_conteudo'
app.get("/criar-tabela", (req, res) => {
  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS primeiro_conteudo (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nivel_texto INTEGER NOT NULL,
      dsc_titulo TEXT NOT NULL,
      dsc_texto TEXT NOT NULL,
      nivel_pergunta INTEGER NOT NULL,
      dsc_pergunta TEXT NOT NULL,
      alternativa_a TEXT NOT NULL,
      alternativa_b TEXT NOT NULL,
      alternativa_c TEXT NOT NULL,
      alternativa_d TEXT NOT NULL,
      resposta_correta TEXT NOT NULL
    )
  `;

  db.run(createTableSQL, (err) => {
    if (err) {
      res.status(500).send("Erro ao criar tabela: " + err.message);
    } else {
      res.send("Tabela 'primeiro_conteudo' criada com sucesso.");
    }
  });
});
app.get("/criar-tabela", (req, res) => {
  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS primeiro_conteudo (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nivel_texto INTEGER NOT NULL,
      dsc_titulo TEXT NOT NULL,
      dsc_texto TEXT NOT NULL,
      nivel_pergunta INTEGER NOT NULL,
      dsc_pergunta TEXT NOT NULL,
      alternativa_a TEXT NOT NULL,
      alternativa_b TEXT NOT NULL,
      alternativa_c TEXT NOT NULL,
      alternativa_d TEXT NOT NULL,
      resposta_correta TEXT NOT NULL
    )
  `;

  db.run(createTableSQL, (err) => {
    if (err) {
      res.status(500).send("Erro ao truncate tabela: " + err.message);
    } else {
      res.send("Tabela 'primeiro_conteudo' criada com sucesso.");
    }
  });
});

// Rota para inserir dados na tabela 'primeiro_conteudo' pelo postman
app.post("/inserir-dados", (req, res) => {
  const {
    nivel_texto,
    dsc_titulo,
    dsc_texto,
    nivel_pergunta,
    dsc_pergunta,
    alternativa_a,
    alternativa_b,
    alternativa_c,
    alternativa_d,
    resposta_correta,
  } = req.body;

  const query = `
    INSERT INTO conteudo (
      nivel_texto,
      dsc_titulo, 
      dsc_texto, 
      nivel_pergunta,
      dsc_pergunta, 
      alternativa_a, 
      alternativa_b, 
      alternativa_c, 
      alternativa_d, 
      resposta_correta) 
    VALUES(?, ?, ?, ?,?, ?, ?, ?, ?, ?)
  `;

  db.run(
    query,
    [
      nivel_texto,
      dsc_titulo,
      dsc_texto,
      nivel_pergunta,
      dsc_pergunta,
      alternativa_a,
      alternativa_b,
      alternativa_c,
      alternativa_d,
      resposta_correta,
    ],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      } else {
        res.send({ message: "Dados inseridos com sucesso", id: this.lastID });
      }
    },
  );
});

// Rota para deletar um usuário pelo nivel_texto
app.delete("/delete", (req, res) => {
  const nivelTexto = req.params.nivel_texto;
  db.run(
    `DELETE FROM primeiro_conteudo WHERE nivel_texto = ?`,
    nivelTexto,
    function (err) {
      if (err) {
        return res.status(400).json({ error: err.message });
      }
      res.json({
        message: `Registro com nivel_texto ${nivelTexto} deletado com sucesso`,
        changes: this.changes,
      });
    },
  );
});

app.listen(PORT, () => {
  console.log(`Servidor de inserção rodando na porta ${PORT}`);
});
