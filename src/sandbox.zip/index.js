/**
 * Módulo express.
 * @const express
 */
var express = require("express");

/**
 * Instância do aplicativo Express.
 * @const app
 */
var app = express();

/**
 * Middleware para fazer parsing de requisições com corpo no formato JSON.
 * @const bodyParser
 */
var bodyParser = require("body-parser");

const bcrypt = require("bcrypt");

/**
 * Porta do servidor. Utiliza a porta definida no ambiente ou padrão 3001.
 * @const {number} PORT
 */
var PORT = process.env.PORT || 3001;

// Middleware para fazer parsing de requisições com corpo no formato JSON
app.use(bodyParser.json());

// Middleware para fazer parsing de requisições com corpo codificado no formato URL
app.use(bodyParser.urlencoded({ extended: true }));

/**
 * Rota principal.
 * @name GET:/
 * @function
 * @param {Object} req - Objeto de requisição.
 * @param {Object} res - Objeto de resposta.
 */
app.get("/", function (req, res) {
  res.send("Rodando o LALALA");
});

/**
 * Rota para retornar uma resposta HTML.
 * @name GET:/html
 * @function
 * @param {Object} req - Objeto de requisição.
 * @param {Object} res - Objeto de resposta.
 */
app.get("/html", function (req, res) {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HTML Response</title>
    </head>
    <body>
        <h1>Hello, this is an HTML response!</h1>
        <p>You can include any HTML content here.</p>
    </body>
    </html>
`);
});

/**
 * Módulo para acesso ao banco de dados SQLite.
 * @const sqlite3
 */
var sqlite3 = require("sqlite3").verbose();

/**
 * Caminho do arquivo do banco de dados.
 * @const {string} DBPATH
 */
var DBPATH = "dados.db";

/**
 * Instância do banco de dados SQLite.
 * @const db
 */
var db = new sqlite3.Database(DBPATH, (err) => {
  if (err) {
    console.error("Erro ao abrir o banco de dados:", err.message);
  } else {
    console.log("Conectado ao banco de dados SQLite.");
  }
});

app.listen(PORT, () => {
  console.log(`Servidor de inserção rodando na porta ${PORT}`);
});
// fim lóca para inserir dados na tabela conteudo

/**
 * Lógica de validação de senha.
 * @function validarSenha
 * @param {string} senha - A senha a ser validada.
 * @returns {boolean} Retorna true se a senha for válida, false caso contrário.
 */

app.get("/selecao", function (req, res) {
  db.all(
    `
          SELECT * FROM conteudo
          
          `,
    [],
    (err, rows) => {
      if (err) {
        res.status(500).send(err.message);
      } else {
        res.json(rows);
      }
    },
  );
});
// selecao do conteudo de html basico
app.get("/selecao-conteudo-1", function (req, res) {
  db.all(
    `
        SELECT * FROM conteudo
         WHERE "nivel_pergunta" = 1
         ORDER BY RANDOM()
        LIMIT 10
        `,
    [],
    (err, rows) => {
      if (err) {
        res.status(500).send(err.message);
      } else {
        res.json(rows);
      }
    },
  );
});
app.get("/selecao-conteudo-2", function (req, res) {
  db.all(
    `
        SELECT * FROM conteudo
         WHERE "nivel_pergunta" = 2
         ORDER BY RANDOM()
        LIMIT 10
        `,
    [],
    (err, rows) => {
      if (err) {
        res.status(500).send(err.message);
      } else {
        res.json(rows);
      }
    },
  );
});
app.get("/selecao-conteudo-3", function (req, res) {
  db.all(
    `
        SELECT * FROM conteudo
         WHERE "nivel_pergunta" = 3
         ORDER BY RANDOM()
        LIMIT 10
        `,
    [],
    (err, rows) => {
      if (err) {
        res.status(500).send(err.message);
      } else {
        res.json(rows);
      }
    },
  );
});
app.get("/selecao-conteudo-4", function (req, res) {
  db.all(
    `
        SELECT * FROM conteudo
         WHERE "nivel_pergunta" = 4
         ORDER BY RANDOM()
        LIMIT 10
        `,
    [],
    (err, rows) => {
      if (err) {
        res.status(500).send(err.message);
      } else {
        res.json(rows);
      }
    },
  );
});
function validarSenha(senha) {
  // Verificar se a senha tem pelo menos 8 caracteres, uma letra maiúscula,
  // uma letra minúscula e um caractere especial
  const regex =
    /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+}{:;'"\/?.>,<]).{8,}$/;
  return regex.test(senha);
}

// lógica de inserção na tabela cadasrto
app.post("/cadastro", async (req, res) => {
  const { dsc_nome_user, senha } = req.body;

  try {
    // Verificar se a senha atende aos critérios de validação
    if (!validarSenha(senha)) {
      return res
        .status(400)
        .send(
          "Senha inválida. A senha deve conter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula e um caractere especial.",
        );
    }

    // Gerar um hash da senha usando bcrypt
    const hashedPassword = await bcrypt.hash(senha, 10);

    // Inserir usuário no banco de dados com a senha criptografada
    db.run(
      `
        INSERT INTO usuario (dsc_nome_user, senha) VALUES (?, ?)
        `,
      [dsc_nome_user, hashedPassword],
      (err) => {
        if (err) {
          return res.status(500).send(err.message);
        }
        res.send("Usuário cadastrado com sucesso!");
      },
    );
  } catch (error) {
    console.error("Erro durante o cadastro do usuário:", error);
    res.status(500).send("Erro durante o cadastro do usuário.");
  }
});
/**
 * Rota para login de usuário.
 * @name POST:/login
 * @function
 * @param {Object} req - Objeto de requisição.
 * @param {Object} res - Objeto de resposta.
 */
app.post("/login", (req, res) => {
  const { senha, dsc_nome_user } = req.body;
  db.get(
    `
      SELECT * FROM usuario WHERE dsc_nome_user = ?
      `,
    [dsc_nome_user],
    async (err, row) => {
      if (err) {
        return res.status(500).send(err.message);
      }
      if (!row) {
        return res.status(401).send("Credenciais inválidas.");
      }
      const isMatch = await bcrypt.compare(senha, row.senha);
      if (!isMatch) {
        return res.status(401).send("Credenciais inválidas.");
      }
      res.send("Login bem-sucedido!");
      // Aqui você pode gerar e enviar um token de autenticação para o usuário
    },
  );
});

// Rota para inserir progresso do usuário
app.post("/inserir-progresso-usuario", (req, res) => {
  const {
    id_conteudo,
    id_usuario,
    total_correta_primeiro_conteudo,
    total_correta_segundo_conteudo,
    total_correta_terceiro_conteudo,
    total_correta_quarto_conteudo,
  } = req.body;
  const insertProgressoUsuarioQuery = `
      INSERT INTO progresso_usuario (id_primeiro_conteudo, id_usuario, total_correta_primeiro_conteudo, total_correta_segundo_conteudo, total_correta_terceiro_conteudo, total_correta_quarto_conteudo) 
      VALUES (?, ?, ?, ?, ?, ?)
    `;
  db.run(
    insertProgressoUsuarioQuery,
    [
      id_conteudo,
      id_usuario,
      total_correta_primeiro_conteudo,
      total_correta_segundo_conteudo,
      total_correta_terceiro_conteudo,
      total_correta_quarto_conteudo,
    ],
    (err) => {
      if (err) {
        res
          .status(500)
          .send("Erro ao inserir progresso do usuário: " + err.message);
      } else {
        res.send("Progresso do usuário inserido com sucesso.");
      }
    },
  );
});
